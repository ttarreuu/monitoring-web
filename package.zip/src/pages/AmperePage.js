import React from 'react'
import Navbar from '../components/Navbar'

function AmperePage() {
  return (
    <div>
        <Navbar/>
        <div>AmperePage</div>
    </div>
  )
}

export default AmperePage