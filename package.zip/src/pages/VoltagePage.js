import React from 'react'
import Navbar from '../components/Navbar'

function VoltagePage() {
  return (
    <div>
        <Navbar/>
        <div>VoltagePage</div>
    </div>
  )
}

export default VoltagePage